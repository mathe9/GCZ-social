package action;

import java.sql.*;

public class add {
	
	String writer_name=null;
	Connection connect_temp = db.connect();
	Connection connect_tempp = db.connect();
	Connection connect_temppp = db.connect();
	public String ad() {
		return "success";
    }
	
	public String back() {
		return "success";
    }
	
	public String getType() {
		return writer_name;
	}
	public void setType(String writer_name) {
		this.writer_name=writer_name;
	}
	
	public String add() throws SQLException {
		String str[]=null;
		int i=0;
		str=writer_name.split(",");
		java.sql.PreparedStatement flag = null;
		java.sql.ResultSet re1 = null;
		flag=connect_tempp.prepareStatement("select attribute,asker,ee,question1,answer1,question2,answer2,question3,answer3,question4,answer4 from data where attribute=?");
		flag.setString(1, str[1]);
		re1=flag.executeQuery();
		while(re1.next())
		{
			i=1;
		}
		if(i==0)
		{
			
			String sql = "insert into data(attribute,asker,ee,question1,answer1,question2,answer2,question3,answer3,question4,answer4)value (?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pStmt = connect_temp.prepareStatement(sql);
			pStmt.setString(1,str[0]);
			pStmt.setString (2,str[1]);
			pStmt.setString(3,str[2]);
			pStmt.setString (4,str[3]);
			pStmt.setString (5,str[4]);
			pStmt.setString (6,str[5]);
			pStmt.setString (7,str[6]);
			pStmt.setString(8,str[7]);
			pStmt.setString (9,str[8]);
			pStmt.setString (10,str[9]);
			pStmt.setString (11,str[10]);
			pStmt.executeUpdate();
		}
		else
			return "fail";
		return "success";
    }

}
