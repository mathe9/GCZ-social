package action;

import com.opensymphony.xwork2.ActionSupport;
import data.DataStore;

public class Data extends ActionSupport{
	
	private DataStore data;
	
	public String data2()
	{
		System.out.println("name="+data.getName());
		System.out.println("age="+data.getAge());
		return SUCCESS;
	}
	
	public String judge()
	{
		if(!data.getName().equals("a"))
		{
			this.addFieldError("name", "name is error");
			return ERROR;
		}
		return SUCCESS;
	}
	
	public DataStore getData()
	{
		return data;
	}

	public DataStore setData(DataStore x)
	{
		return this.data=x;
	}
}
