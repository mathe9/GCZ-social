package action;

public class table {
	
	public String attribute;
	public String asker;
	public String ee;
	public String question1;
	public String answer1;
	public String queston2;
	public String answer2;
	public String question3;
	public String answer3;
	public String question4;
	public String answer4;

}
