package db;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;


public class Db
{
    private Statement statement;
    String DRIVER_MYSQL = "com.mysql.jdbc.Driver";    //MySQL JDBC�����ַ���
	String URL = "jdbc:mysql://localhost:3306/database";

        
    public Db() {
        try
        {
            Class.forName(DRIVER_MYSQL).newInstance();     //����JDBC����
            //System.out.println("Driver Load Success.");

            java.sql.Connection connection = DriverManager.getConnection(URL);    //�������ݿ����Ӷ���
            statement = (Statement) connection.createStatement();       //����Statement����
        } catch (Exception e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        init();
        
    }
    
    private void init() {
		// TODO Auto-generated method stub
    	String sql = "create table if not exists paper("
    			+ "attribute char(9) primary key"
//        		+ "attribute char(9) primary key,"
//        		+ "asker char(9),"
//        		+ "ee char(9),"
//        		+ "question1 char(99),"
//        		+ "answer1 char(99),"
//        		+ "question2 char(99),"
//        		+ "answer2 char(99),"
//        		+ "question3 char(99),"
//        		+ "answer3 char(99),"
//        		+ "question4 char(99),"
//        		+ "answer4 char(99)"
        		+ ")default charset=utf8";
        executeSql(sql);
        
	}
    
    public ResultSet query(String sql) {
        ResultSet result = null;

        try
        {
            result = statement.executeQuery(sql);
        } catch (SQLException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return result;
    }

    /*
     * ִ�����ݲ���
     * ��    ��:SQL���
     * ����ֵ:��
     */
    public void executeSql(String sql) {
        try
        {
            statement.execute(sql);
        } catch (SQLException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
