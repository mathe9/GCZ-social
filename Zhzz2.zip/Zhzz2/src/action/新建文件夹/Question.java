package action;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import db.Db;

import data.Data;

import com.opensymphony.xwork2.ActionSupport;


public class Question extends ActionSupport{
	
	private Data question = new Data();
	Db db = new Db();
	private String addFlag = null;
	private ArrayList<Data> questionarray = new ArrayList<Data>();
	
	public String question() throws SQLException
	{
		addDataToSql();
        getDataFromSql();
		return SUCCESS;
	}
	
	private void addDataToSql() throws SQLException {
		if(addFlag!=null){
			question.codeProblemSolving();
			String sql = question.toInsertSql();
			System.out.println(sql);
			db.executeSql(sql);
		}
	}
	
	public void getDataFromSql() throws SQLException{
		String sql = "SELECT * FROM author";
        ResultSet result = db.query(sql);
        readResult(result);
	}
	
	public void readResult(ResultSet result) throws SQLException{
		questionarray = new ArrayList<Data>();
		while(result.next()) {
			 Data data = new Data();
			 data.fromResult(result);
			 questionarray.add(data);
		 } 
	 }
	
	
	public ArrayList<Data> getQuestionarray(){
		return this.questionarray;
	}
 
    public void setQuestionarray(ArrayList<Data> data){
		this.questionarray=data;
	}
 
    public Data getQuestion(){
		return this.question;
	}
 
    public void setQuestion(Data data){
		this.question=data;
	}
 
    public String getAddFlag(){
		return this.addFlag;
	}
 
    public void setAddFlag(String addFlag){
		this.addFlag=addFlag;
	}

}
