package data;

import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Data {
	
	public String attribute;
	public String asker;
	public String ee;
	public String question1;
	public String answer1;
	public String question2;
	public String answer2;
	public String question3;
	public String answer3;
	public String question4;
	public String answer4;
	
	public Data(){}
	
public void fromResult(ResultSet result) throws SQLException{
		
    	attribute=result.getString(1);
    	asker=result.getString(2);
    	ee=result.getString(3);
    	question1=result.getString(4);
    	answer1=result.getString(5);
    	question2=result.getString(6);
    	answer2=result.getString(7);
    	question3=result.getString(8);
    	answer3=result.getString(9);
    	question4=result.getString(10);
    	answer4=result.getString(11);
	}

public String toInsertSql()
{
	 String sql= "INSERT INTO book VALUES";
	 sql+="(";
	 sql+="'"+attribute+"',";
	 sql+="'"+asker+"',";
	 sql+="'"+ee+"',";
	 sql+="'"+question1+"',";
	 sql+="'"+answer1+"',";
	 sql+="'"+question2+"',";
	 sql+="'"+answer2+"',";
	 sql+="'"+question3+"',";
	 sql+="'"+answer3+"',";
	 sql+="'"+question4+"',";
	 sql+="'"+answer4+"'";
	 sql+=");";		
	 return sql;
}

public void show(){
	System.out.println("attribute:" + attribute);
	System.out.println("asker:" + asker);
	System.out.println("ee:" + ee);
	System.out.println("question1:" + question1);
	System.out.println("answer1:" + answer1);
	System.out.println("question2:" + question2);
	System.out.println("answer2:" + answer2);
	System.out.println("question3:" + question3);
	System.out.println("answer3:" + answer3);
	System.out.println("question4:" + question4);
	System.out.println("answer4:" + answer4);
 }
	
	public String getAttribute()
	{
		return attribute;
	}
	
	public void setAttribute(String attribute)
	{
		this.attribute=attribute;
	}
	
	public String getAsker()
	{
		return asker;
	}
	
	public void setAsker(String asker)
	{
		this.asker=asker;
	}
	
	public String getEe()
	{
		return ee;
	}
	
	public void setEe(String ee)
	{
		this.ee=ee;
	}
	
	public String getQuestion1()
	{
		return question1;
	}
	
	public void setQuestion1(String question1)
	{
		this.question1=question1;
	}
	
	public String getAnswer1()
	{
		return answer1;
	}
	
	public void setAnswer1(String answer1)
	{
		this.answer1=answer1;
	}
	
	public String getQuesion2()
	{
		return question2;
	}
	
	public void setQuestion2(String question2)
	{
		this.question2=question2;
	}
	
	public String getAnswer2()
	{
		return answer2;
	}
	
	public void setAnswer2(String answer2)
	{
		this.answer2=answer2;
	}

	public String getQuesion3()
	{
		return question3;
	}
	
	public void setQuestion3(String question3)
	{
		this.question3=question3;
	}
	
	public String getAnswer3()
	{
		return answer3;
	}
	
	public void setAnswer3(String answer3)
	{
		this.answer3=answer3;
	}

	public String getQuesion4()
	{
		return question4;
	}
	
	public void setQuestion4(String question4)
	{
		this.question4=question4;
	}
	
	public String getAnswer4()
	{
		return answer4;
	}
	
	public void setAnswer4(String answer4)
	{
		this.answer4=answer4;
	}

	public void codeProblemSolving() {
//		// TODO Auto-generated method stub
		try {
			attribute=new String(attribute.getBytes("ISO-8859-1"),"UTF-8");
			asker=new String(asker.getBytes("ISO-8859-1"),"UTF-8");
			ee=new String(ee.getBytes("ISO-8859-1"),"UTF-8");
			question1=new String(question1.getBytes("ISO-8859-1"),"UTF-8");
			answer1=new String(answer1.getBytes("ISO-8859-1"),"UTF-8");
			question2=new String(question2.getBytes("ISO-8859-1"),"UTF-8");
			answer2=new String(answer2.getBytes("ISO-8859-1"),"UTF-8");
			question3=new String(question3.getBytes("ISO-8859-1"),"UTF-8");
			answer3=new String(answer3.getBytes("ISO-8859-1"),"UTF-8");
			question4=new String(question4.getBytes("ISO-8859-1"),"UTF-8");
			answer4=new String(answer4.getBytes("ISO-8859-1"),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
